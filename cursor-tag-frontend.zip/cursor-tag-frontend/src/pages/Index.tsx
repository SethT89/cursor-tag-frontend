import React, { useState, useCallback, useEffect, useRef } from 'react';
import HomeScreen from '../components/HomeScreen';
import LobbyScreen from '../components/LobbyScreen';
import GameArena from '../components/GameArena';
import ResultsScreen from '../components/ResultsScreen';
import { Player, LeaderboardEntry, GamePhase, ServerMessage } from '../game/gameTypes';
import { useGameSocket } from '../hooks/useGameSocket';

const Index = () => {
  const { send, onMessage, connected } = useGameSocket();

  const [phase, setPhase] = useState<GamePhase>('home');
  const [roomCode, setRoomCode] = useState('');
  const [localPlayerId, setLocalPlayerId] = useState('');
  const [isHost, setIsHost] = useState(false);
  const [players, setPlayers] = useState<Player[]>([]);
  const [itPlayerId, setItPlayerId] = useState('');
  const [timeLeft, setTimeLeft] = useState(60000);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [results, setResults] = useState<Player[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [error, setError] = useState<string>('');

  // Throttled mouse move sender
  const lastSentRef = useRef(0);
  const handleMouseMove = useCallback((x: number, y: number) => {
    const now = Date.now();
    if (now - lastSentRef.current < 50) return; // max 20/s
    lastSentRef.current = now;
    send({ type: 'move', x, y });
  }, [send]);

  // Message handler
  useEffect(() => {
    const unsubscribe = onMessage((msg: ServerMessage) => {
      switch (msg.type) {
        case 'roomCreated':
          setRoomCode(msg.roomCode);
          setLocalPlayerId(msg.playerId);
          setPlayers(msg.players);
          setIsHost(true);
          setLeaderboard(msg.leaderboard || []);
          setError('');
          setPhase('lobby');
          break;

        case 'roomJoined':
          setRoomCode(msg.roomCode);
          setLocalPlayerId(msg.playerId);
          setPlayers(msg.players);
          setIsHost(false);
          setError('');
          setPhase('lobby');
          break;

        case 'playerJoined':
        case 'playerLeft':
          setPlayers(msg.players);
          break;

        case 'countdown':
          setCountdown(msg.count);
          if (phase !== 'countdown') setPhase('countdown');
          break;

        case 'gameStarted':
          setPlayers(msg.players);
          setItPlayerId(msg.itPlayerId);
          setTimeLeft(msg.duration);
          setCountdown(null);
          setPhase('playing');
          break;

        case 'gameState':
          setPlayers(msg.players);
          setItPlayerId(msg.itPlayerId);
          setTimeLeft(msg.timeLeft);
          break;

        case 'tagged':
          // Visual feedback handled by gameState updates
          break;

        case 'gameEnded':
          setResults(msg.players);
          setLeaderboard(msg.leaderboard || []);
          setPhase('results');
          break;

        case 'error':
          setError(msg.message);
          break;
      }
    });
    return unsubscribe;
  }, [onMessage, phase]);

  // Fetch leaderboard on connect
  useEffect(() => {
    if (connected && phase === 'home') {
      send({ type: 'getLeaderboard' });
    }
  }, [connected, send, phase]);

  const handleCreateGame = useCallback((name: string) => {
    setError('');
    send({ type: 'createRoom', name });
  }, [send]);

  const handleJoinGame = useCallback((name: string, code: string) => {
    setError('');
    send({ type: 'joinRoom', name, roomCode: code });
  }, [send]);

  const handleStartGame = useCallback(() => {
    send({ type: 'startGame' });
  }, [send]);

  const handlePlayAgain = useCallback(() => {
    setPhase('lobby');
    setResults([]);
    setPlayers(prev => {
      // Players stay in lobby — server handles reset
      return prev;
    });
  }, []);

  const handleHome = useCallback(() => {
    setPhase('home');
    setRoomCode('');
    setLocalPlayerId('');
    setPlayers([]);
    setResults([]);
    setIsHost(false);
    setError('');
    send({ type: 'getLeaderboard' });
  }, [send]);

  if (phase === 'home') {
    return (
      <HomeScreen
        onCreateGame={handleCreateGame}
        onJoinGame={handleJoinGame}
        leaderboard={leaderboard}
        connected={connected}
        error={error}
      />
    );
  }

  if (phase === 'lobby') {
    return (
      <LobbyScreen
        roomCode={roomCode}
        players={players}
        localPlayerId={localPlayerId}
        isHost={isHost}
        onStartGame={handleStartGame}
        onBack={handleHome}
      />
    );
  }

  if (phase === 'countdown' || phase === 'playing') {
    return (
      <GameArena
        players={players}
        localPlayerId={localPlayerId}
        itPlayerId={itPlayerId}
        timeLeft={timeLeft}
        countdown={phase === 'countdown' ? countdown : null}
        onMouseMove={handleMouseMove}
      />
    );
  }

  if (phase === 'results') {
    return (
      <ResultsScreen
        players={results}
        leaderboard={leaderboard}
        onPlayAgain={handlePlayAgain}
        onHome={handleHome}
      />
    );
  }

  return null;
};

export default Index;
